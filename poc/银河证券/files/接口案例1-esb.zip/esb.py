#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
import uuid

import requests

from tools.Crypter import Crypter

logger = logging.getLogger('console')


class EsbCaller(object):
    """Esb请求者"""

    def build_headers(self, user, password, func_no, func_version, sysCode):
        headers = {}
        headers['Content-Type'] = 'application/json;charset=UTF-8'
        headers['Tracking-Id'] = str(uuid.uuid4())
        headers['User'] = user
        crypter = Crypter()
        nonce = crypter.generate_nonce()
        timestamp = crypter.generate_timestamp()
        headers['Nonce'] = nonce
        headers['Created'] = timestamp
        headers['Password-Digest'] = crypter.generate_password_digest(nonce, timestamp, password)
        headers['Function-No'] = func_no
        headers['Function-Version'] = func_version
        headers['Caller-System-Code'] = sysCode
        headers['Accept-Encoding'] = ''
        return headers

    def post(self, url, header, request):
        logger.info("req:%s, %s, %s", url, request, header)
        result = requests.post(url, data=request, headers=header)
        logger.info("res:%s", result.text)
        return result

# func_no = "YH0007000400004"
# func_version = "1"
# sysCode = 'MPA'
# request = '{"CustNo":"10300010053", "OprMode":"B", "OrgNo":"0103", "AssetAcct":"", "FortuneAcct":"-1"}'
# caller = EsbCaller()
# headers = caller.build_headers("mpa", 'china@123', func_no, func_version, sysCode)
# result = caller.post("http://10.1.85.106:22112/apiJson/V2/mpa", headers, request)
# print('应答header')
# print(result.headers)
# print('应答body')
# print(result.content.decode("utf-8"))
